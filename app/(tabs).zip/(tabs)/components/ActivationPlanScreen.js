import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useAuth } from '../AuthContext';
import { initiateGooglePayPayment } from './PaymentScreen'; // Example service function to initiate Google Pay payment

const ActivationPlanScreen = ({ navigation }) => {
  const { login } = useAuth();

  const handlePayment = async () => {
    try {
      // Call a service function to initiate Google Pay payment
      const paymentResponse = await initiateGooglePayPayment(250); // Example amount in rupees (₹250)

      if (paymentResponse.success) {
        // Payment successful
        alert('Payment Successful', 'You have successfully paid for the activation plan.');

        // Simulate setting paid status or any logic you need
        login(); // Example of setting logged in state

        // Navigate to the main app screen (home screen)
        navigation.navigate('MainApp');
      } else {
        // Payment failed or was canceled
        alert('Payment Error', 'Payment was not successful. Please try again.');
      }
    } catch (error) {
      console.error('Error processing payment:', error);
      alert('Payment Error', 'There was an error processing your payment. Please try again later.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Activation Plan</Text>
      <Text style={styles.description}>Please pay ₹250 to activate your account.</Text>
      <TouchableOpacity style={styles.button} onPress={handlePayment}>
        <Text style={styles.buttonText}>Pay Now with Google Pay</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 30,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  description: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 30,
  },
  button: {
    width: '100%',
    padding: 12,
    backgroundColor: '#50b458',
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default ActivationPlanScreen;

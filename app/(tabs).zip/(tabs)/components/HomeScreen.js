// HomeScreen.js

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, AsyncStorage } from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons'; // Assuming FontAwesome5 for icons
import ProfileImage from '../assets/mycoin.jpeg'; // Replace with your profile image path
import CoinImage from '../assets/gold.jpg'; // Replace with your coin image path
import { useAuth } from '../AuthContext';

const HomeScreen = ({ navigation }) => {
  const { user } = useAuth();
  const [coins, setCoins] = useState(0);
  const [lastCheckDate, setLastCheckDate] = useState(null);

  useEffect(() => {
    const fetchCoins = async () => {
      const storedCoins = await AsyncStorage.getItem('coins');
      const storedDate = await AsyncStorage.getItem('lastCheckDate');
      if (storedCoins) setCoins(parseInt(storedCoins, 10));
      if (storedDate) setLastCheckDate(new Date(storedDate));
    };

    fetchCoins();
  }, []);

  const handleDailyCheck = async () => {
    const today = new Date();
    if (!lastCheckDate || today.getDate() !== lastCheckDate.getDate()) {
      const newCoins = coins + 1;
      setCoins(newCoins);
      setLastCheckDate(today);
      await AsyncStorage.setItem('coins', newCoins.toString());
      await AsyncStorage.setItem('lastCheckDate', today.toISOString());
      alert('Daily Check', 'You have earned one coin for today!');
    } else {
      alert('Daily Check', 'You have already earned your coin for today!');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.profileHeader}>
        <Image source={ProfileImage} style={styles.profileImage} />
        <Text style={styles.profileName}>{user?.name}</Text>
        <Text style={styles.profileEmail}>{user?.email}</Text>
      </View>
      <View style={styles.walletContainer}>
        <Image source={CoinImage} style={styles.coinImage} />
        <Text style={styles.coinsText}>My Earnings: {coins}</Text>
      </View>
      <View style={styles.profileDetails}>
        <TouchableOpacity style={styles.profileItem} onPress={handleDailyCheck}>
          <FontAwesome5 name="calendar-check" size={24} color="#1693B8" />
          <Text style={styles.profileItemText}>Daily Check</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:'#D5D9EF',
    padding: 20,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  profileName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  profileEmail: {
    fontSize: 16,
    color: '#666',
  },
  walletContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  coinImage: {
    width: 40,
    height: 40,
    marginBottom: 10,
  },
  coinsText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000',
  },
  profileDetails: {
    marginTop: 20,
  },
  profileItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  profileItemText: {
    marginLeft: 16,
    fontSize: 18,
    color: '#333',
  },
});

export default HomeScreen;

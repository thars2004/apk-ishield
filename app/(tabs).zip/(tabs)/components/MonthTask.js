import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, AsyncStorage } from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons';

const MonthTask = ({ route }) => {
  const { completedTasks } = route.params;

  const [tasks, setTasks] = useState([
    { id: '1', name: 'Task 1', icon: 'sync', completed: true },
    { id: '2', name: 'Task 2', icon: 'clone', completed: true },
    { id: '3', name: 'Task 3', icon: 'coins', completed: false },
    { id: '4', name: 'Task 4', icon: 'dice', completed: false },
    { id: '5', name: 'Task 5', icon: 'paint-brush', completed: false },
  ]);

  useEffect(() => {
    const fetchCompletedTasks = async () => {
      const storedTasksString = await AsyncStorage.getItem('monthTasks');
      if (storedTasksString) {
        const storedTasks = JSON.parse(storedTasksString);
        setTasks(storedTasks.filter(task => completedTasks.includes(task.id))); // Filter tasks based on completedTasks array
      } else {
        const initialTasks = tasks.map((task, index) => ({
          ...task,
          completed: index < 2,
        }));
        setTasks(initialTasks);
        await AsyncStorage.setItem('monthTasks', JSON.stringify(initialTasks));
      }
    };
    fetchCompletedTasks();
  }, [completedTasks, tasks]); // Include 'tasks' in the dependency array

  const renderTaskIcon = (completed, iconName) => {
    const iconColor = completed ? '#009d2a' : '#ff0000';
    return <FontAwesome5 name={iconName} size={20} color={iconColor} style={styles.taskIcon} />;
  };

  const renderTaskItem = ({ item }) => (
    <TouchableOpacity style={styles.taskContainer}>
      <View style={styles.taskItem}>
        {renderTaskIcon(item.completed, item.icon)}
        <Text style={[styles.taskText, item.completed && { color: '#0F9D58' }]}>
          {item.name} - {item.completed ? 'Completed' : 'Incomplete'}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Month Tasks</Text>
      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={renderTaskItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor:'#D5D9EF',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
  },
  taskContainer: {
    marginBottom: 10,
    borderRadius: 8,
    backgroundColor: '#faf6f6', // Updated background color of each task container
    padding: 10,
    shadowColor: '#1c1c1c', // Updated shadow color
    shadowOffset: { width: 0, height: 2 }, // Shadow offset
    shadowOpacity: 0.25, // Shadow opacity
    shadowRadius: 3.84, // Shadow radius
    elevation: 3,
    height: 80, // Fixed height of each task container
    justifyContent: 'center', // Center align vertically
    alignItems: 'center', // Center align horizontally
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  taskText: {
    fontSize: 18,
    color: '#ff0000',
    marginLeft: 10,
  },
  taskIcon: {
    marginRight: 10,
  },
});

export default MonthTask;

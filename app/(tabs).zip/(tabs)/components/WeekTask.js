import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, AsyncStorage } from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons';

const WeekTask = ({ route }) => {
  const { completedTasks } = route.params;

  const [tasks, setTasks] = useState([
    { id: '1', name: 'Spin and Earn', icon: 'sync', completed: true },
    { id: '2', name: 'Flip the Card', icon: 'clone', completed: true },
    { id: '3', name: 'Coin Flip and Earn', icon: 'coins', completed: false },
    { id: '4', name: 'Drop the Dice', icon: 'dice', completed: false },
    { id: '5', name: 'Reveal the Scratch Card', icon: 'paint-brush', completed: false },
  ]);

  useEffect(() => {
    const fetchCompletedTasks = async () => {
      const storedTasksString = await AsyncStorage.getItem('weekTasks');
      if (storedTasksString) {
        const storedTasks = JSON.parse(storedTasksString);
        setTasks(storedTasks.filter(task => completedTasks.includes(task.id)));
      } else {
        const initialTasks = tasks.map((task, index) => ({
          ...task,
          completed: index < 2,
        }));
        setTasks(initialTasks);
        await AsyncStorage.setItem('weekTasks', JSON.stringify(initialTasks));
      }
    };
    fetchCompletedTasks();
  }, [completedTasks, tasks]); // Include 'tasks' in the dependency array

  const renderTaskIcon = (completed, iconName) => {
    const iconColor = completed ? '#009d2a' : '#DB4437';
    return <FontAwesome5 name={iconName} size={20} color={iconColor} style={styles.taskIcon} />;
  };

  const renderTaskItem = ({ item }) => (
    <TouchableOpacity style={styles.taskContainer}>
      <View style={styles.taskItem}>
        {renderTaskIcon(item.completed, item.icon)}
        <Text style={[styles.taskText, item.completed && { color: '#009d2a' }]}>
          {item.name} - {item.completed ? 'Completed' : 'Incomplete'}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.outerContainer}>
      <View style={styles.container}>
        <Text style={styles.heading}>Week Tasks</Text>
        <FlatList
          data={tasks}
          keyExtractor={(item) => item.id}
          renderItem={renderTaskItem}
          contentContainerStyle={styles.listContainer}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor:'#D5D9EF',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
  },
  listContainer: {
    flexGrow: 1,
  },
  taskContainer: {
    marginBottom: 10,
    borderRadius: 8,
    backgroundColor: '#faf6f6', // Updated background color of each task container
    padding: 10,
    shadowColor: '#1c1c1c', // Updated shadow color
    shadowOffset: { width: 0, height: 2 }, // Shadow offset
    shadowOpacity: 0.25, // Shadow opacity
    shadowRadius: 3.84, // Shadow radius
    elevation: 3,
    height: 80, // Fixed height of each task container
    justifyContent: 'center', // Center align vertically
    alignItems: 'center', // Center align horizontally
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center', // Center align vertically
    flex: 1, // Take full height of taskContainer
  },
  taskText: {
    fontSize: 18,
    color: '#ff0000',
    marginLeft: 10,
  },
  taskIcon: {
    marginRight: 10,
  },
});

export default WeekTask;

import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';

const PinLockScreen = () => {
  const [pin, setPin] = useState('');
  const navigation = useNavigation();

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
  };

  const handlePinChange = (value) => {
    if (pin.length < 4) {
      setPin(pin + value);
    }
  };

  const handleSubmit = () => {
    if (pin.length === 4) {
      navigation.navigate('MainApp');
    } else {
      alert('Enter a 4-digit PIN');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter PIN</Text>
      <TextInput
        style={styles.input}
        value={pin}
        secureTextEntry
        keyboardType='numeric'
        maxLength={4}
        editable={false} // Disable keyboard
        onChangeText={(text) => {}}
      />
      <View style={styles.buttonContainer}>
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
          <TouchableOpacity key={num} style={styles.numberButton} onPress={() => handlePinChange(num.toString())}>
            <Text style={styles.numberText}>{num}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={styles.bottomButtonsContainer}>
        <TouchableOpacity style={styles.iconButton} onPress={handleDelete}>
          <Icon name="backspace-outline" size={24} color="#1693B8" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.numberButton} onPress={() => handlePinChange('0')}>
          <Text style={styles.numberText}>0</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconButton} onPress={handleSubmit}>
          <Icon name="checkmark-circle-outline" size={24} color="#1693B8" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const { width, height } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor:'#D5D9EF',
  },
  title: {
    fontSize: width * 0.08,
    marginBottom: height * 0.03,
    color: '#000',
    fontFamily: 'Lora-Regular', // Apply Lora font
  },
  input: {
    width: width * 0.5,
    height: height * 0.07,
    fontSize: width * 0.06,
    borderBottomWidth: 1,
    textAlign: 'center',
    marginBottom: height * 0.03,
    color: '#000',
    fontFamily: 'Lora-Regular', // Apply Lora font
  },
  buttonContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    width: width * 0.6, // Adjust width to fit 3 columns of buttons
    marginBottom: height * 0.02,
    backgroundColor:'#D5D9EF',
  },
  numberButton: {
    width: width * 0.18, // Adjust width for 3 columns
    height: width * 0.18, // Adjust height for buttons to be square
    justifyContent: 'center',
    alignItems: 'center',
    margin: width * 0.01, // Adjust margin to create spacing
    borderWidth: 0, // Remove border
    backgroundColor:'#D5D9EF',
  },
  numberText: {
    fontSize: width * 0.06,
    color: '#000',
    fontFamily: 'Lora-Regular', // Apply Lora font
  },
  bottomButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: width * 0.6,
    marginBottom: height * 0.02,
  },
  iconButton: {
    width: width * 0.18, // Adjust width for icon buttons
    height: width * 0.18, // Adjust height for icon buttons
    justifyContent: 'center',
    alignItems: 'center',
    margin: width * 0.01, // Margin between buttons
    borderWidth: 0, // Remove border
    backgroundColor:'#D5D9EF',  },
});

export default PinLockScreen;

import React, { createContext, useState, useContext } from 'react';
import axios from 'axios'; // Ensure axios is installed

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);

  const login = async (userData) => {
    setIsLoggedIn(true);
    setUser(userData);
  };

  const logout = () => {
    setIsLoggedIn(false);
    setUser(null);
  };

  const activateUser = async (userId) => {
    try {
      const response = await axios.post(`http://localhost:3306/activate-account/${userId}`);
      setUser(response.data);
    } catch (error) {
      console.error('Failed to activate user:', error.message);
    }
  };

  const fetchUser = async (userId) => {
    try {
      const response = await axios.get(`http://localhost:3306/user/${userId}`);
      setUser(response.data);
    } catch (error) {
      console.error('Failed to fetch user data:', error.message);
    }
  };

  return (
    <AuthContext.Provider value={{ isLoggedIn, user, login, logout, activateUser, fetchUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);

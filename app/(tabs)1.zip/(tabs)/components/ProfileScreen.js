// ProfileScreen.js (React Native/Expo)

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TextInput, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../AuthContext'; // Adjust path as needed

const ProfileScreen = () => {
  const { user, logout } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [userData, setUserData] = useState({
    name: '',
    email: '',
    phone: '',
    bankId: '',
    ifsc: '',
    balance: '',
    referralCode: '',
    kycStatus: '',
    district: '',
    profileImage: '',
  });

  useEffect(() => {
    if (user) {
      setUserData({
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || '',
        bankId: user.bank_acc_no || '',
        ifsc: user.ifsc_code || '',
        balance: user.total_amount || '',
        referralCode: user.empid || '',
        kycStatus: user.kycStatus || '',
        district: user.district || '',
        profileImage: user.profileImage || '',
      });
    }
  }, [user]);
  
  const handleInputChange = (field, value) => {
    setUserData({ ...userData, [field]: value });
  };
  
  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });
  
    if (!result.cancelled) {
      setUserData({ ...userData, profileImage: result.uri });
    }
  };
  
  const removeImage = () => {
    alert(
      'Remove Image',
      'Are you sure you want to remove the profile image?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Yes', onPress: () => setUserData({ ...userData, profileImage: '' }) },
      ],
      { cancelable: false }
    );
  };
  

  const takePhoto = async () => {
    let result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.cancelled) {
      setUserData({ ...userData, profileImage: result.uri });
    }
  };

  const saveProfileChanges = async () => {
    try {
      console.log('Saving profile changes:', userData); // Add this line
      const response = await fetch(`http://localhost:3306/profile/${user.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: userData.name,
          bankId: userData.bankId,
          ifsc: userData.ifsc,
          district: userData.district,
          profileImage: userData.profileImage,
        }),
      });
  
      const data = await response.json();
      if (response.ok) {
        alert('Profile updated successfully');
        setIsEditing(false); // Exit edit mode after saving changes
      } else {
        console.error('Failed to update profile:', data.error);
        // Handle error scenario
      }
    } catch (error) {
      console.error('Failed to update profile:', error);
    }
  };
  
  

  const handleLogout = () => {
    logout();
    navigation.navigate('Login');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.profileContainer}>
        {userData.profileImage ? (
          <Image
            source={{ uri: userData.profileImage }}
            style={styles.profileImage}
          />
        ) : (
          <Ionicons name="person-circle" size={100} color="#007BFF" />
        )}
        {isEditing && (
          <View style={styles.imageButtonsContainer}>
            <TouchableOpacity style={styles.imageButton} onPress={pickImage}>
              <Text style={styles.buttonText}>Pick Image</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.imageButton} onPress={removeImage}>
              <Text style={styles.buttonText}>Remove Image</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {isEditing ? (
        <>
          <TextInput
            style={styles.input}
            value={userData.name}
            onChangeText={(text) => handleInputChange('name', text)}
            placeholder="Name"
            placeholderTextColor="#ccc"
          />
          <TextInput
            style={styles.input}
            value={userData.email} // Email is not editable
            editable={false} // Prevent editing
            placeholder="Email"
            placeholderTextColor="#ccc"
          />
          <TextInput
            style={styles.input}
            value={userData.phone} // Phone is not editable
            editable={false} // Prevent editing
            placeholder="Phone"
            placeholderTextColor="#ccc"
          />
          <TextInput
            style={styles.input}
            value={userData.bankId}
            onChangeText={(text) => handleInputChange('bankId', text)}
            placeholder="Bank ID"
            placeholderTextColor="#ccc"
          />
          <TextInput
            style={styles.input}
            value={userData.ifsc}
            onChangeText={(text) => handleInputChange('ifsc', text)}
            placeholder="IFSC"
            placeholderTextColor="#ccc"
          />
          <TextInput
            style={styles.input}
            value={userData.district}
            onChangeText={(text) => handleInputChange('district', text)}
            placeholder="District"
            placeholderTextColor="#ccc"
          />
        </>
      ) : (
        <View style={styles.table}>
          <View style={styles.tableRow}>
            <Text style={styles.tableTitle}>Name:</Text>
            <Text style={styles.tableText}>{userData.name}</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableTitle}>Email:</Text>
            <Text style={styles.tableText}>{userData.email}</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableTitle}>Phone:</Text>
            <Text style={styles.tableText}>{userData.phone}</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableTitle}>Bank ID:</Text>
            <Text style={styles.tableText}>{userData.bankId}</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableTitle}>IFSC:</Text>
            <Text style={styles.tableText}>{userData.ifsc}</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableTitle}>Account Balance:</Text>
            <Text style={styles.tableText}>{userData.balance}</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableTitle}>Referral Code:</Text>
            <Text style={styles.tableText}>{userData.referralCode}</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableTitle}>KYC Status:</Text>
            <Text style={styles.tableText}>{userData.kycStatus}</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableTitle}>District:</Text>
            <Text style={styles.tableText}>{userData.district}</Text>
          </View>
        </View>
      )}

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.customButton} onPress={() => navigation.navigate('TransactionHistory')}>
          <Text style={styles.buttonText}>View Transaction History</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.customButton} onPress={() => navigation.navigate('AccountSettings')}>
          <Text style={styles.buttonText}>Account Settings</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.customButton} onPress={() => navigation.navigate('HelpSupport')}>
          <Text style={styles.buttonText}>Help & Support</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.customButton, styles.logoutButton]} onPress={handleLogout}>
          <Text style={styles.buttonText}>Logout</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={styles.editButton}
        onPress={() => {
          if (isEditing) {
            saveProfileChanges(); // Save changes if exiting edit mode
          }
          setIsEditing(!isEditing);
        }}
      >
        <Ionicons name={isEditing ? "checkmark" : "pencil"} size={24} color={isEditing ? "green" : "white"} />
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#D5D9EF',
    padding: 20,
    position: 'relative',
  },
  profileContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginTop: -100,
  },
  imageButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  imageButton: {
    backgroundColor: '#6C757D',
    padding: 10,
    borderRadius: 5,
    marginHorizontal: 5,
  },
  table: {
    width: '100%',
    marginBottom: 20,
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  tableTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  tableText: {
    fontSize: 18,
    color: '#555',
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    width: '80%',
    padding: 10,
    color: '#333',
  },
  buttonContainer: {
    width: '100%',
    marginTop: 20,
  },
  customButton: {
    backgroundColor: '#6C757D',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 10,
  },
  logoutButton: {
    backgroundColor: '#002740',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  editButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    padding: 6,
    backgroundColor: '#6C757D',
    borderRadius: 3,
  },
});

export default ProfileScreen;

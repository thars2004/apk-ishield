import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons';

const MonthTask = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const response = await fetch('http://localhost:3306/tasks/monthly');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setTasks(data);
      } catch (error) {
        console.error('Error fetching tasks:', error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchTasks();
  }, []);

  const renderTaskIcon = (completed, iconName) => {
    const iconColor = completed ? '#009d2a' : '#ff0000';
    return <FontAwesome5 name={iconName} size={20} color={iconColor} style={styles.taskIcon} />;
  };

  const renderTaskItem = ({ item }) => (
    <TouchableOpacity style={styles.taskContainer}>
      <View style={styles.taskItem}>
        {renderTaskIcon(item.completed, item.icon)}
        <Text style={[styles.taskText, item.completed && { color: '#0F9D58' }]}>
          {item.title} - {item.completed ? 'Completed' : 'Incomplete'}
        </Text>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Error: {error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Monthly Tasks</Text>
      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={renderTaskItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor:'#D5D9EF',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
  },
  taskContainer: {
    marginBottom: 10,
    borderRadius: 8,
    backgroundColor: '#faf6f6',
    padding: 10,
    shadowColor: '#1c1c1c',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  taskText: {
    fontSize: 18,
    color: '#ff0000',
    marginLeft: 10,
  },
  taskIcon: {
    marginRight: 10,
  },
  errorText: {
    color: 'red',
    fontSize: 18,
    textAlign: 'center',
  },
});

export default MonthTask;

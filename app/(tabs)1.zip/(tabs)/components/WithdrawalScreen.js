import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import TextInputField from '../components/TextInputField';

const WithdrawalScreen = () => {
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const navigation = useNavigation();

  const handleWithdraw = () => {
    // Validation logic
    if (!accountNumber || !accountName || !ifscCode || !withdrawAmount) {
      alert('Error', 'All fields are required.');
      return;
    }

    // Add your withdrawal logic here
    console.log('Withdraw details:', { accountNumber, accountName, ifscCode, withdrawAmount });

    // Display success message
    alert('Success', 'Withdrawal request submitted successfully.');

    // After processing, navigate back to the WalletScreen
    navigation.goBack();
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.label}>Account Number:</Text>
      <TextInputField
        style={styles.input}
        value={accountNumber}
        onChangeText={setAccountNumber}
        keyboardType="numeric"
      />
      <Text style={styles.label}>Account Name:</Text>
      <TextInputField
        style={styles.input}
        value={accountName}
        onChangeText={setAccountName}
      />
      <Text style={styles.label}>IFSC Code:</Text>
      <TextInputField
        style={styles.input}
        value={ifscCode}
        onChangeText={setIfscCode}
      />
      <Text style={styles.label}>Withdraw Amount:</Text>
      <TextInputField
        style={styles.input}
        value={withdrawAmount}
        onChangeText={setWithdrawAmount}
        keyboardType="numeric"
      />
      <TouchableOpacity style={styles.withdrawButton} onPress={handleWithdraw}>
        <Text style={styles.withdrawButtonText}>Withdraw</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 30,
    backgroundColor: '#D5D9EF',
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'black',
    marginBottom: 10,
  },
  input: {
    width: '100%',
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 20,
  },
  withdrawButton: {
    width: '100%',
    padding: 15,
    backgroundColor: '#002740',
    borderRadius: 8,
    alignItems: 'center',
  },
  withdrawButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default WithdrawalScreen;

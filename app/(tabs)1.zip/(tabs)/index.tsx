import { registerRootComponent } from 'expo';
import App from './App'; // Ensure this path is correct

// Register the main component to start the app
registerRootComponent(App);
